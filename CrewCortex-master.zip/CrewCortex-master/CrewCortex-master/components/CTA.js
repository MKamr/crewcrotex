function CTA() {
  const CTA = document.getElementById("CTA");
  const Container = document.createElement("div");
  Container.classList.add("container");
  Container.innerHTML = `
  <div class="row row-cols-1 row-cols-lg-2 gx-5">
  <div class="text-body col py-5">
    <h2 class="title fw-bold">
          Got Questions?
    </h2>
    <p>
We’re here to help! Contact us for any questions or support.
    </p>
    <form class="contact-form mt-4" action="https://formspree.io/f/mdkordak" method="POST">
      <div id="confirmation-message" class="alert alert-success d-none">
        Thank you for your message! We'll get back to you soon.
      </div>
      <div class="mb-3">
        <input type="text" class="form-control" id="fullName" name="fullName" placeholder="Full Name" required>
      </div>
      <div class="mb-3">
        <input type="email" class="form-control" id="email" name="email" placeholder="Email Address" required>
      </div>
      <div class="mb-3">
        <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required>
      </div>
      <div class="mb-3">
        <textarea class="form-control" id="message" name="message" rows="4" placeholder="Your Message" required></textarea>
      </div>
      <button type="submit" class="btn btn-primary">Send Message</button>
    </form>
  </div>
  <div class="col container-body overflow-hidden">
    <img class="img-fluid" src="./Images/mockup-mobiles.png" alt="" />
  </div>
</div>
  `;
  CTA.appendChild(Container);

  // Add form submission handler
  const form = Container.querySelector('.contact-form');
  const confirmationMessage = Container.querySelector('#confirmation-message');

  form.addEventListener('submit', function(e) {
    const formData = new FormData(form);
    fetch(form.action, {
      method: 'POST',
      body: formData,
      headers: {
        'Accept': 'application/json'
      }
    })
    .then(response => {
      if (response.ok) {
        form.reset();
        confirmationMessage.classList.remove('d-none');
        setTimeout(() => {
          confirmationMessage.classList.add('d-none');
        }, 5000); // Hide message after 5 seconds
      } else {
        throw new Error('Form submission failed');
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('There was a problem submitting your form. Please try again.');
    });
    e.preventDefault();
  });
}
CTA();
