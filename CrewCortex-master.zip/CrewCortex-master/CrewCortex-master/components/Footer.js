function Footer() {
  const Footer = document.getElementById("Footer");
  const Container = document.createElement("div");
  Container.classList.add("container");
  Container.innerHTML = `
  <div class="row gx-4 gy-5">
          <div class="col-12 left-section">
            <div class="brand-logo">
              <a class="navbar-brand" href="#">
                <img class="BrandLogo" src="./Images/CCLogoWhite.svg" alt="" srcset="" />
              </a>
            </div>
            <div class="nav-links d-flex flex-column mt-4">
              <ul class="nav justify-content-left row-1">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="#">Contact Now</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Licence</a>
                </li>
              </ul>
              <ul class="nav justify-content-left row-2">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="#Metric">About</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#Features">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#Pricing">Pricing</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Why Us?</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Contacts</a>
                </li>
              </ul>
            </div>
            <div class="copyrights mt-4">
              © 2021 <a class='text-decoration-underline' href="">CrewCortex</a> Theme. All rights reserved
            </div>
          </div>
        </div>
  `;
  Footer.appendChild(Container);
}
Footer();
